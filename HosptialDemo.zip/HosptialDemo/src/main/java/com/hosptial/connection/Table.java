package com.hosptial.connection;

public class Table {
	

}
